# Website Portofolio Hanan Asril

## Menjalankan
1. Ekstrak folder/ZIP.
2. Buka `index.html` dengan browser untuk melihat website secara lokal.

## Publikasi gratis
- **Netlify Drop:** buka https://app.netlify.com/drop lalu unggah folder yang berisi `index.html`.
- **GitHub Pages:** unggah `index.html` ke repository GitHub, lalu aktifkan Pages pada Settings.

## Personalisasi sebelum dipublikasikan
- Foto profil sudah memakai `foto-hanan-asril.jpeg`. Area galeri masih berupa placeholder desain; ganti dengan foto asli jika diinginkan.
- Periksa kembali tanggal, nilai, kontak, serta semua tautan profil sebelum dipublikasikan.
- Website ini dibuat sebagai satu file HTML mandiri, responsif untuk desktop dan ponsel, tanpa instalasi atau dependensi eksternal.
